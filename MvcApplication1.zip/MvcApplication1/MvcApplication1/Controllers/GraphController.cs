﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MvcApplication1.Controllers
{
    public class GraphController : Controller
    {
        //
        // GET: /Graph/
        public ActionResult Index()
        {

            return View();
        }
    }
}
